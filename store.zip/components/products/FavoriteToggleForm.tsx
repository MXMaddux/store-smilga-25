function FavoriteToggleForm() {
  return <div>FavoriteToggleForm</div>;
}
export default FavoriteToggleForm;
