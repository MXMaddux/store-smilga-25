function EditProductPage() {
  return <div>EditProductPage</div>;
}
export default EditProductPage;
