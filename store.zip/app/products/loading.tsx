"use client";

import LoadingContainer from "@/components/global/LoadingContainer";

function loading() {
  return <LoadingContainer />;
}
export default loading;
